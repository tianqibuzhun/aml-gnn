from AML_GCN import load_data, GCN_Net
import torch
import numpy as np
import pandas as pd
from datetime import datetime

# Load data
account_path = "./data/1K_outputs/accounts.csv"
transaction_path = "./data/1K_outputs/transactions.csv"
edge_index, x, accouts_num, labels, features_dim, idx_train_num = load_data(account_path, transaction_path)
print("features_dim.shape：{}".format(features_dim))

# Model and optimizer
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = GCN_Net(features_dim, 16, 2).to(device)

model = torch.load("./model/AML-GCN.ph")
model.eval()

# 模型预测结果
_, pred = model(x, edge_index).max(dim=1)
# print(pred)
# 保存数据
account_sar = np.arange(accouts_num)
account_sar = np.column_stack((account_sar, pred))
# print(account_sar)

# 创建数据帧
data_df = pd.DataFrame(account_sar)
data_df.columns = ['acct_id','prior_sar_count']

now = datetime.now()  # 获得当前时间
timestr = now.strftime("%Y_%m_%d_%H_%M_%S")
file_name = timestr+".csv"
file_path = "./data/pred/"+file_name
data_df.to_csv(file_path, index=False)
