import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelBinarizer

import torch
import torch.nn.functional as F
from torch_geometric.nn import GCNConv

import time

from DeepWalk import get_randomwalk, deepwalk


def load_data(account_path, transaction_path):
    """
    加载account和transection数据
    :param account_path: accounts.csv文件
    :param transaction_path: transactions.csv文件
    :return:
        edge_index: 无向图 [2,E]
        x: 节点特征
        accouts_num: 节点数量
        labels: 节点标签
        features_dim: 节点特征维度
        idx_train_num: 训练集数量
    '''
    """

    # 加载accounts.cvs
    dataframe_accounts = pd.read_csv(account_path)

    # 记录account数量
    accouts_num = len(dataframe_accounts)

    # 标签
    labels = dataframe_accounts['prior_sar_count']
    one_hot_labels = LabelBinarizer()
    labels = one_hot_labels.fit_transform(labels)

    print("labels:")
    print(labels)

    # 节点特征One-Hot编码（已经更换为DeepWalk Embedding）
    # dataframe_accounts_dropped = dataframe_accounts.drop(['dsply_nm', 'prior_sar_count', 'open_dt',
    #                                                       'close_dt', 'initial_deposit', 'tx_behavior_id',
    #                                                       'first_name', 'last_name', 'street_addr', 'zip',
    #                                                       'birth_date', 'ssn', 'lon', 'lat'], axis=1)
    # column_names = [column for column in dataframe_accounts_dropped]
    # column_names.remove('acct_id')
    # one_hot = LabelBinarizer()
    # features = one_hot.fit_transform(dataframe_accounts_dropped['acct_id'])
    # for column_name in column_names:
    #     one_hot = LabelBinarizer()
    #     one_hot_embedding = one_hot.fit_transform(dataframe_accounts_dropped[column_name])
    #     features = np.append(features, one_hot_embedding, axis=1)

    # 节点特征维度（DeepWalk中直接设定为256）
    # features_dim = features.shape[1]
    features_dim = 256

    # 初始化节点特征矩阵
    features = np.zeros((accouts_num, 256))
    # 对节点进行DeepWalk Embedding
    features = deepwalk(transaction_path, features)

    # 设置训练集数量
    idx_train_num = int(accouts_num * 0.7)

    # 读取transections.csv
    dataframe_transactions = pd.read_csv(transaction_path)

    # 构建无向图
    edge_index = np.array(dataframe_transactions[['orig_acct', 'bene_acct']])
    edge_index_2 = edge_index[:, [1, 0]]
    edge_index = np.append(edge_index.T, edge_index_2.T, axis=1)

    # 返回数据
    edge_index = torch.tensor(edge_index, dtype=torch.long)
    x = torch.tensor(features, dtype=torch.float)
    labels = torch.tensor(labels[:, 0], dtype=torch.long)

    return edge_index, x, accouts_num, labels, features_dim, idx_train_num


class GCN_Net(torch.nn.Module):
    def __init__(self, features, hidden, classes):
        super(GCN_Net,self).__init__()
        self.conv1 = GCNConv(features, hidden)
        self.conv2 = GCNConv(hidden, classes)

    def forward(self, x, edge_index):
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = F.dropout(x, training=self.training)
        x = self.conv2(x, edge_index)

        return F.log_softmax(x, dim=1)


def train():
    # Load data
    account_path = "./data/1K_outputs/accounts.csv"
    transaction_path = "./data/1K_outputs/transactions.csv"
    edge_index, x, accouts_num, labels, features_dim, idx_train_num = load_data(account_path, transaction_path)
    print("features_dim.shape：{}".format(features_dim))

    # Model and optimizer
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = GCN_Net(features_dim, 16, 2).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

    # Train
    model.train()
    idx_train = range(idx_train_num)
    for epoch in range(200):
        t = time.time()
        optimizer.zero_grad()
        out = model(x, edge_index)
        loss = F.nll_loss(out[idx_train], labels[idx_train])

        # 验证集
        # _, pred = out.max(dim=1)
        # correct = pred[idx_train_num:].eq(labels[idx_train_num:]).sum()
        # acc = int(correct)/int(labels[idx_train_num:, :].sum())

        loss.backward()
        optimizer.step()

        # print('Epoch: {:04d}'.format(epoch + 1),
        #       'loss_train: {:.4f}'.format(loss.item()),
        #       # 'acc_train: {:.4f}'.format(acc.item()),
        #       'time: {:.4f}s'.format(time.time() - t))

    model.eval()
    _, pred = model(x, edge_index).max(dim=1)
    correct = pred[idx_train_num:].eq(labels[idx_train_num:]).sum()
    acc = int(correct) / int(accouts_num - idx_train_num)
    print('AML-GCN准确率：{:.4f}'.format(acc))

    # 保存模型
    torch.save(model, "./model/AML-GCN.ph")


if __name__ == '__main__':
    train()
