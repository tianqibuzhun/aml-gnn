import networkx as nx # 图数据挖掘

# 数据分析
import pandas as pd
import numpy as np

import random # 随机数
from tqdm import tqdm # 进度条

# 数据可视化
import matplotlib.pyplot as plt
# 自然语言处理
from gensim.models import Word2Vec

plt.rcParams['font.sans-serif']=['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus']=False  # 用来正常显示负号


def get_randomwalk(G, node, path_length):
    '''
    输入起始节点和路径长度，生成随机游走节点序列
    '''

    random_walk = [node]

    for i in range(path_length - 1):
        # 汇总邻接节点
        temp = list(G.neighbors(node))
        temp = list(set(temp) - set(random_walk))
        if len(temp) == 0:
            break
        # 从邻接节点中随机选择下一个节点
        random_node = random.choice(temp)
        random_walk.append(random_node)
        node = random_node

    return random_walk


def deepwalk(edge_path, node_embedding):
    """
    :param edge_path: 边数据文件
    :param node_embedding: 节点特征编码（初始为one-hot编码）
    :return: node_embedding： 节点特征编码（对边涉及的节点进行deepwalk编码）
    """
    transections_df = pd.read_csv(edge_path)
    transections_df = transections_df[['orig_acct', 'bene_acct']]
    # 查看边的数量
    # print(transections_df.shape)

    G = nx.from_pandas_edgelist(transections_df, "orig_acct", "bene_acct", edge_attr=None, create_using=nx.Graph())
    # 查看图涉及的边
    # print(len(G))
    all_nodes = list(G.nodes())
    # print(all_nodes)

    # # 可视化
    # plt.figure(figsize=(15,14))
    # nx.draw(G)
    # plt.show()

    # print(get_randomwalk(96, 5))

    gamma = 10  # 每个节点作为起始点生成随机游走序列个数
    walk_length = 5  # 随机游走序列最大长度

    random_walks = []

    for n in tqdm(all_nodes):  # 遍历每个节点
        for i in range(gamma):  # 每个节点作为起始点生成gamma个随机游走序列
            random_walks.append(get_randomwalk(G, n, walk_length))

    # 生成随机游走序列个数
    # print(len(random_walks))
    # print(random_walks[1])

    # 训练Word2Vec模型
    model = Word2Vec(vector_size=256,  # Embedding维数
                     window=4,  # 窗口宽度
                     sg=1,  # Skip-Gram
                     hs=0,  # 不加分层softmax
                     negative=10,  # 负采样
                     alpha=0.03,  # 初始学习率
                     min_alpha=0.0007,  # 最小学习率
                     seed=14  # 随机数种子
                     )

    # 用随机游走序列构建词汇表
    model.build_vocab(random_walks, progress_per=2)

    # 训练
    print("DeepWalk Embedding")
    model.train(random_walks, total_examples=model.corpus_count, epochs=50, report_delay=1)
    print("Finish DeepWalk Embedding")

    # 查看节点的Embedding
    wv = model.wv
    for node in all_nodes:
        node_embedding[node] = wv.get_vector(node)
    return node_embedding


if __name__ == '__main__':
    node_embedding = np.zeros((100, 256))
    # print(node_embedding)
    node_embedding = deepwalk("./data/100_outputs/transactions.csv", node_embedding)
    print(node_embedding)
